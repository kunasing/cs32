#include "MovieDatabase.h"
#include "Movie.h"

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
using namespace std;

MovieDatabase::MovieDatabase()
{
    // DOES NOTHING
}

bool MovieDatabase::load(const string& filename)
{
    ifstream moviefile(filename);
    string line;
    
    while (moviefile){
        int step = 1;
        float rating = 0;
        string id, name, year, directors, actors, genres;
        
        while(getline(moviefile, line) && line != ""){
            switch(step){
                case 1:
                    id = line;
                    break;
                case 2:
                    name = line;
                    break;
                case 3:
                    year = line;
                    break;
                case 7:
                    rating = stof(line);
                    break;
                case 4:
                    directors = line;
                    break;
                case 5:
                    actors = line;
                    break;
                case 6:
                    genres = line;
                    break;
                default:
                    break;
            }
            
            step++;
        }
        
        if (id != ""){
            vector<string> vDirectors = seperateAndInsert(directors);
            vector<string> vActors = seperateAndInsert(actors);
            vector<string> vGenres = seperateAndInsert(genres);

            Movie toAdd = Movie(id, name, year, vDirectors, vActors, vGenres, rating);
            m_moviesByID.insert(id, toAdd);
            for (int i = 0; i < vDirectors.size(); i++)
                m_moviesByDirector.insert(vDirectors[i], toAdd);
            for (int i = 0; i < vActors.size(); i++)
                m_moviesByActor.insert(vActors[i], toAdd);
            for (int i = 0; i < vGenres.size(); i++)
                m_moviesByGenre.insert(vGenres[i], toAdd);
        }
        
    }
    
    return false;  // Replace this line with correct code.
}

Movie* MovieDatabase::get_movie_from_id(const string& id) const
{
    TreeMultimap<std::string, Movie>::Iterator it = m_moviesByID.find(id);
    return &it.get_value();
}

vector<Movie*> MovieDatabase::get_movies_with_director(const string& director) const
{
    TreeMultimap<std::string, Movie>::Iterator it = m_moviesByDirector.find(director);
    vector<Movie*> movies;
    while (it.is_valid()){
        movies.push_back(&it.get_value());
        it.advance();
    }
    
    return movies;  // Replace this line with correct code.
}

vector<Movie*> MovieDatabase::get_movies_with_actor(const string& actor) const
{
    TreeMultimap<std::string, Movie>::Iterator it = m_moviesByActor.find(actor);
    vector<Movie*> movies;
    while (it.is_valid()){
        movies.push_back(&it.get_value());
        it.advance();
    }
    
    return movies;
}

vector<Movie*> MovieDatabase::get_movies_with_genre(const string& genre) const
{
    TreeMultimap<std::string, Movie>::Iterator it = m_moviesByGenre.find(genre);
    vector<Movie*> movies;
    while (it.is_valid()){
        movies.push_back(&it.get_value());
        it.advance();
    }
    
    return movies;
}

vector<string> MovieDatabase::seperateAndInsert(string multi){
    vector<string> v;

    stringstream ss(multi);

    while (ss.good()) {
        string substr;
        getline(ss, substr, ',');
        v.push_back(substr);
    }

    return v;
}
