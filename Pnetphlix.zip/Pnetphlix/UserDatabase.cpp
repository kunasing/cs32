#include "UserDatabase.h"
#include "User.h"
#include "treemm.h"

#include <string>
#include <vector>
#include <iostream>
using namespace std;

UserDatabase::UserDatabase()
{
   
}

bool UserDatabase::load(const string& filename)
{
    ifstream userfile(filename);
    string line;
    
    while (userfile){
        int step = 1;
        string name, email;
        vector<string> movies;
        
        while(getline(userfile, line) && line != ""){
            switch(step){
                case 1:
                    name = line;
                    break;
                case 2:
                    email = line;
                    break;
                case 3:
                    break;
                default:
                    movies.push_back(line);
                    break;
            }
            
            step++;
            
        }
        
        if (name != ""){
            m_users.insert(email, User(name, email, movies));
        }
        
        if (!userfile)
            break;
    }
    return false;  // Replace this line with correct code.
}

User* UserDatabase::get_user_from_email(const string& email) const
{
    TreeMultimap<std::string, User>::Iterator it = m_users.find(email);
    return &it.get_value();
}

